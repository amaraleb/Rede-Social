console.log("olá mundo!");

const log = ["mesmo", "teste", "outro"];
const key = ["mesmo", "teste", "outro"];


var user
var psw



function Entrar() {
    $("#entrar").on('click', function() {
        user = $("#user").val();
        psw = $("#psw").val();
        i = log.findIndex(vlog);
        function vlog (usuario){
            return usuario == user;
        }
        if(i>=0){
            if(psw==key[i]){
                window.location="profile.html";
            } else{
                window.alert("Senha inválida");
            }
        } else {
            window.alert("Usuário inválido");
        }
        
    });
}

